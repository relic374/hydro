# Hydro

The Hydro CLI is a way to quickly and easily package electron apps without the need for large commands.
Currently it has the bare bones features needed to package an app, but please let me know if you have any suggestions of electron packager flags to use! My discord: `Relic374#4880`

# Installation

## Non-Python Dependencies
1. Electron
2. Electron Packager

## Install

Install with `pipx hydro-relic374`. Run using `hydro`. 
